echo "--------------------------------------"
echo " apt install"
echo "--------------------------------------"
sudo apt update
sudo apt install -y vim
sudo apt install -y gawk
sudo apt install -y gcc
sudo apt install -y autoconf
sudo apt install -y pkg-config
sudo apt install -y libtool
sudo apt install -y libgmp-dev
sudo apt install -y make
sudo apt install -y bison
sudo apt install -y flex
sudo apt install -y traceroute
sudo apt install -y net-tools 
sudo apt install -y curl 
sudo apt install -y libpcap-dev
sudo apt install -y pcaputils
sudo apt install -y zlib1g-dev

# for dig/drill
sudo apt install -y ldnsutils

#sudo apt install -y strongswan
#cat << EOT | sudo tee -a /etc/ipsec.conf
#conn test_transport
#      auto=start
#      type=transport
#      keyexchange=ikev2
#      authby=psk
#      leftsubnet=192.168.61.0/24
#      right=10.1.2.1
#      rightsubnet=192.168.62.0/24
#      ike=aes256-sha256-modp1024
#      esp=aes256-sha256-modp1024
#      keyingtries=%forever
#      ikelifetime=28800s
#      lifetime=28800s
#      dpddelay=60s
#      dpdtimeout=120s
#      dpdaction=restart
#EOT
#
#cat << EOT | sudo tee -a /etc/ipsec.conf
#conn test_transport
#      auto=start
#      type=transport
#      keyexchange=ikev2
#      authby=psk
#      leftsubnet=192.168.61.0/24
#      right=10.1.2.1
#      rightsubnet=192.168.62.0/24
#      ike=aes256-sha256-modp1024
#      esp=aes256-sha256-modp1024
#      keyingtries=%forever
#      ikelifetime=28800s
#      lifetime=28800s
#      dpddelay=60s
#      dpdtimeout=120s
#      dpdaction=restart
#EOT

echo "--------------------------------------"
echo " dns setteing"
echo "--------------------------------------"
