
# 接続確認[strongSwan - libreSwan]

## 確認条件

#### strongSwanのバージョン
vagrant@router1:/etc$ ipsec --version
Linux strongSwan U5.8.2/K5.4.0-139-generic
University of Applied Sciences Rapperswil, Switzerland
See 'ipsec --copyright' for copyright information.

#### libreSwanのバージョン
vagrant@router2:~$ ipsec --version
Linux Libreswan 3.29 (netkey) on 5.4.0-139-generic

## ネットワーク構成

```puml
@startuml
<style>
nwdiagDiagram {
  network {
    BackGroundColor Orange
  }
  server {
    BackGroundColor LemonChiffon
    LineColor black
    FontStyle bold
    Shadowing 1
  }
  arrow {
    FontSize 12
    FontColor Red
    FontStyle bold
    LineColor Chocolate
  }
}
</style>

nwdiag {
  network prvnet1 {
    address = "10.1.0.0/16";
    router1 [address = "10.1.1.1"];
    router2 [address = "10.1.2.1"];
  }
  network subnet1 {
    address = "192.168.61.0/24";
    router1 [address = "192.168.61.101"];
  }
  network subnet2 {
    address = "192.168.62.0/24";
    router2 [address = "192.168.62.101"];
  }

}
@enduml
```

