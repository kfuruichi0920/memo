#!/bin/bash

readonly CA_KEY=ca.key.pem
readonly CA_CRT=ca.crt.pem
readonly SRV_KEY=srv.key.pem
readonly SRV_REQ=srv.req.pem
readonly SRV_CRT=srv.crt.pem
readonly SRV_COMMON_NAME=192.168.100.17
readonly CLI_KEY=cli.key.pem
readonly CLI_REQ=cli.req.pem
readonly CLI_CRT=cli.crt.pem
readonly CLI_COMMON_NAME=192.168.200.1

readonly SRV_ORGANIZATION=TMK.COMMPF
readonly OUTPUT=./output

rm /etc/ipsec.d/cacerts/*
rm /etc/ipsec.d/certs/*
rm /etc/ipsec.d/private/*
rm -rf ${OUTPUT}
mkdir -p ${OUTPUT}

# create root cert
cakey=${OUTPUT}/${CA_KEY}
cacrt=${OUTPUT}/${CA_CRT}
ipsec pki --gen --type rsa --size 3072 --outform pem > ${cakey}
ipsec pki --self --ca --lifetime 3652 --in ${cakey} --dn "C=JP, O=strongSwan, CN=strongSwanVPN CA" --outform pem > ${cacrt}
ipsec pki --print --in ${cacrt}

# copy /etc/ipsec.d/*
cp ${cakey} /etc/ipsec.d/private/
cp ${cacrt} /etc/ipsec.d/cacerts/
chmod 600 /etc/ipsec.d/private/${CA_KEY}
chmod 600 /etc/ipsec.d/cacerts/${CA_CRT}
chown root:root /etc/ipsec.d/private/${CA_KEY}
chown root:root /etc/ipsec.d/cacerts/${CA_CRT}


# create server cert
srvkey=${OUTPUT}/${SRV_KEY}
srvreq=${OUTPUT}/${SRV_REQ}
srvcrt=${OUTPUT}/${SRV_CRT}
ipsec pki --gen --type rsa --size 3072 --outform pem > ${srvkey}
ipsec pki --req --type priv --in ${srvkey} --dn "C=JP, O=${SRV_ORGANIZATION}, CN=${SRV_COMMON_NAME}" --san ${SRV_COMMON_NAME} --outform pem > ${srvreq} 
ipsec pki --issue --cacert ${cacrt} --cakey ${cakey} --type pkcs10 --in ${srvreq} --flag serverAuth --serial 01 --lifetime 1826 --outform pem > ${srvcrt}
ipsec pki --print --in ${srvcrt}

# copy /etc/ipsec.d/*
cp ${srvkey} /etc/ipsec.d/private/
cp ${srvcrt} /etc/ipsec.d/certs/
chmod 600 /etc/ipsec.d/private/${SRV_KEY}
chmod 600 /etc/ipsec.d/certs/${SRV_CRT}
chown root:root /etc/ipsec.d/private/${SRV_KEY}
chown root:root /etc/ipsec.d/certs/${SRV_CRT}


# create client cert
clikey=${OUTPUT}/${CLI_KEY}
clireq=${OUTPUT}/${CLI_REQ}
clicrt=${OUTPUT}/${CLI_CRT}
ipsec pki --gen --type rsa --size 3072 --outform pem > ${clikey}
ipsec pki --req --type priv --in ${clikey} --dn "C=JP, O=${SRV_ORGANIZATION}, CN=${CLI_COMMON_NAME}" --san ${CLI_COMMON_NAME} --outform pem > ${clireq} 
ipsec pki --issue --cacert ${cacrt} --cakey ${cakey} --type pkcs10 --in ${clireq} --flag serverAuth --serial 01 --lifetime 1826 --outform pem > ${clicrt}
ipsec pki --print --in ${clicrt}

# copy /etc/ipsec.d/*
cp ${clikey} /etc/ipsec.d/private/
cp ${clicrt} /etc/ipsec.d/certs/
chmod 600 /etc/ipsec.d/private/${CLI_KEY}
chmod 600 /etc/ipsec.d/certs/${CLI_CRT}
chown root:root /etc/ipsec.d/private/${CLI_KEY}
chown root:root /etc/ipsec.d/certs/${CLI_CRT}
